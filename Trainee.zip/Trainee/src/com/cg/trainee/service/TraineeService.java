package com.cg.trainee.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.beans.Trainee;
import com.cg.trainee.dao.ITraineeDao;

@Service
public class TraineeService implements ITraineeService{
	@Autowired
	ITraineeDao traineeDao;
	
	
	public ITraineeDao getTraineeDao() {
		return traineeDao;
	}
	
	
	public void setTraineeDao(ITraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}

	@Override
	public Trainee addTrainee(Trainee trainee) {
		return traineeDao.addTrainee(trainee);
	}


	@Override
	public Trainee deleteTrainee(int traineeId) {
		return traineeDao.deleteTrainee(traineeId);
	}


	@Override
	public void deleteTraineeDetails(int traineeId) {
		traineeDao.deleteTraineeDetails(traineeId);
	}

}
