package com.cg.trainee.service;

import com.cg.trainee.beans.Trainee;

public interface ITraineeService {

	Trainee addTrainee(Trainee trainee);

	Trainee deleteTrainee(int traineeId);

	void deleteTraineeDetails(int traineeId);

}
