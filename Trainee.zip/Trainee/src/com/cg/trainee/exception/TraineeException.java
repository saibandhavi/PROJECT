package com.cg.trainee.exception;

public class TraineeException extends Exception {
	public TraineeException() {

	}

	public TraineeException(String message) {
		super(message);
	}

}
