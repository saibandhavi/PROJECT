package com.cg.trainee.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.beans.Trainee;
import com.cg.trainee.service.ITraineeService;

@Controller
public class TraineeController {
	@Autowired
	private ITraineeService traineeService;

	public ITraineeService getTraineeService() {
		return traineeService;
	}

	public void setTraineeService(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}

	@RequestMapping("/login")
	public String login() {
		return "login";
	}

	@RequestMapping("/operations")
	public String operations() {
		return "operation";
	}

	@RequestMapping("/addTraineeForms")
	public ModelAndView showAddTrainee() {
		Trainee trainee = new Trainee();

		return new ModelAndView("addTraineeForm", "trainee", trainee);
	}

	@RequestMapping("/addTrainee")
	public ModelAndView addTrainee(
			@ModelAttribute("trainee") @Valid Trainee trainee,
			BindingResult result) {

		ModelAndView view = null;

		if (!result.hasErrors()) {
			trainee = traineeService.addTrainee(trainee);
			view = new ModelAndView("addSuccess");
			view.addObject("traineeId", trainee.getTraineeId());
			view.addObject("traineeName", trainee.getTraineeName());
			view.addObject("traineeDomain", trainee.getTraineeDomain());
			view.addObject("traineeLocation", trainee.getTraineeLocation());
		} else {
			view = new ModelAndView("addTraineeForm", "trainee", trainee);
		}
		return view;
	}

	@RequestMapping("/deleteTraineeForms")
	public ModelAndView deleteTrainee() {
		Trainee trainee = new Trainee();

		return new ModelAndView("deleteTraineeForm", "trainee", trainee);
	}

	@RequestMapping("showDeleteDetails")
	public ModelAndView showDeleteDetails() {
		Trainee trainee = new Trainee();

		return new ModelAndView("showDeleteDetails", "trainee", trainee);
	}

	@RequestMapping("/deleteTrainee")
	public ModelAndView deleteTrainee(
			@ModelAttribute("trainee") Trainee trainee) {
		ModelAndView view = new ModelAndView();
		Trainee trainee1 = new Trainee();
			trainee1 = traineeService.deleteTrainee(trainee.getTraineeId());
			if(trainee1!= null){
				view.setViewName("showDeleteDetails");
				view.addObject("trainee1", trainee1);
			}
		return view;
	}
	
	@RequestMapping("deleteTraineeDetails")
	public ModelAndView deleteTraineeDetails(
		@ModelAttribute("trainee") Trainee trainee) {
		ModelAndView view = new ModelAndView();
			traineeService.deleteTraineeDetails(trainee.getTraineeId());
			
				view.setViewName("deleteSuccess");
			
		return view;
	}
}