package com.cg.trainee.dao;

import com.cg.trainee.beans.Trainee;

public interface ITraineeDao {

	Trainee addTrainee(Trainee trainee);

	Trainee deleteTrainee(int traineeId);

	void deleteTraineeDetails(int traineeId);


}
