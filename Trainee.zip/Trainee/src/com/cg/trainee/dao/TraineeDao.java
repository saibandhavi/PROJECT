package com.cg.trainee.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.trainee.beans.Trainee;
@Repository
@Transactional
public class TraineeDao implements ITraineeDao {

	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Trainee addTrainee(Trainee trainee) {
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee;
	}

	@Override
	public Trainee deleteTrainee(int traineeId) {
		return entityManager.find(Trainee.class, traineeId);
	}

	@Override
	public void deleteTraineeDetails(int traineeId) {
		Trainee trainee1=entityManager.find(Trainee.class, traineeId);
		entityManager.remove(trainee1);
	}
}