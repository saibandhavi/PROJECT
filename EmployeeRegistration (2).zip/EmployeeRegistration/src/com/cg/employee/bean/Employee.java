package com.cg.employee.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

import com.sun.istack.internal.NotNull;

@Entity
@Table(name = "emp_details")
public class Employee {
	
	
	
	@Id
	private int employeeId;

	@NotEmpty(message = "Please Enter Employee Name")
	@Pattern(regexp = "^[A-Z]{1}[a-z]+$", message = "Username must contain only alphabets")
	private String employeeName;

	@NotNull
	private Double salary;

	@NotEmpty(message = "Project name should not be null")
	@Pattern(regexp = "^[A-Z]{1}[a-z]+$", message = "Project name should start with uppercase")
	private String projName;

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", salary=" + salary + ", projName="
				+ projName + "]";
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public String getProjName() {
		return projName;
	}

	public void setProjName(String projName) {
		this.projName = projName;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Employee(int employeeId, String employeeName, Double salary,
			String projName) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salary = salary;
		this.projName = projName;
	}

	public Employee() {
		super();
	}

}
