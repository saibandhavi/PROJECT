package com.cg.employee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.employee.bean.Employee;


@Repository
@Transactional
public class EmployeeDaoImpl implements IEmployeeDao{

	
	@PersistenceContext
	private EntityManager entityManager;

	
	@Override
	public Employee addEmployee(Employee employee) {
		entityManager.persist(employee);
		entityManager.flush();
		return employee;
	}


	@Override
	public List<Employee> viewAllEmployee() {
		TypedQuery<Employee> query=entityManager.createQuery("SELECT e from Employee e",Employee.class);
		return query.getResultList();
	}

}
