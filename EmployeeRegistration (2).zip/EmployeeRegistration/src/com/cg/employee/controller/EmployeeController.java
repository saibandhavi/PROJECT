package com.cg.employee.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employee.bean.Employee;
import com.cg.employee.service.IEmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	IEmployeeService empService;

	public IEmployeeService getEmpService() {
		return empService;
	}

	public void setEmpService(IEmployeeService empService) {
		this.empService = empService;
	}

	@RequestMapping("/index")
	public String index() {
		return "index";
	}

	@RequestMapping("/registration")
	public ModelAndView registration() {
		Employee employee = new Employee();

		return new ModelAndView("addEmployeeForm", "employee", employee);
	}

	@RequestMapping("/addEmployee")
	public ModelAndView addEmployee(
			@ModelAttribute("employee") @Valid Employee employee,
			BindingResult result) {

		ModelAndView view = null;

		if (!result.hasErrors()) {
			employee = empService.addEmployee(employee);
			view = new ModelAndView("addSucess");
			view.addObject("employeeId", employee.getEmployeeId());
			view.addObject("employeeName", employee.getEmployeeName());
			view.addObject("salary", employee.getSalary());
			view.addObject("projName", employee.getProjName());

		} else {
			view = new ModelAndView("addEmployeeForm", "employee", employee);
		}
		return view;
	}
	
	@RequestMapping("/viewAllEmployee")
	public ModelAndView viewAllEmployee()
	{
		ModelAndView mv=new ModelAndView();
		List<Employee> list=empService.viewAllEmployee();
		if(list.isEmpty())
		{
			String message="No Employees";
			mv.setViewName("error");
			mv.addObject("message",message);
		}
		else
		{
			mv.setViewName("viewAllEmployee");
			mv.addObject("list",list);
		}
		return mv;
	}

}
