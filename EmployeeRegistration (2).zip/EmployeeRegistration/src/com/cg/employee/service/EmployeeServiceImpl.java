package com.cg.employee.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employee.bean.Employee;
import com.cg.employee.dao.IEmployeeDao;
@Service
@Transactional
public class EmployeeServiceImpl implements IEmployeeService{

	@Autowired
	IEmployeeDao empDao;
	
	
	public IEmployeeDao getEmpDao() {
		return empDao;
	}


	public void setEmpDao(IEmployeeDao empDao) {
		this.empDao = empDao;
	}


	@Override
	public Employee addEmployee(Employee employee) {
		return empDao.addEmployee(employee);
	}


	@Override
	public List<Employee> viewAllEmployee(){
		return empDao.viewAllEmployee();
	}

}
