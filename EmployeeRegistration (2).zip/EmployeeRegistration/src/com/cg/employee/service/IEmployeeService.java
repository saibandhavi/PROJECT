package com.cg.employee.service;

import java.util.List;

import com.cg.employee.bean.Employee;

public interface IEmployeeService {

	Employee addEmployee(Employee employee);
	
	List<Employee> viewAllEmployee();
}
