package com.cg.employee.exception;

public class EmployeeException {

}
